# Prototype Challenge

![Rev A lens tester assembly](imgs/lens_tester_assembly.png)

This repo contains a Rev A lens tester fixture package and a shop-state snapshot.

## Work order

Review the supplied CAD, drawing, and shop snapshot. Prepare a prototype build plan.

Target:

- one validation unit as soon as practical
- 5-10 follow-on units if the validation unit works
- one accessory for removing the two threaded inserts from the lens tester assembly without using pliers

Separate your first-unit plan from your follow-on build plan.

## Product files

```text
cad/
  lens_tester_revA.step

drawings/
  lens_tester_revA.pdf

imgs/
  lens_tester_assembly.png
```

The mocked PCB geometry is included in the STEP file.

## Shop-state files

```text
shop/
  machine_notes.md
  tool_library_mill.csv
  tool_library_lathe.csv
  stock_list.csv
  inventory.csv
  printer_materials.csv
  maintenance_log.md
```

Treat these as a snapshot of the shop state at the time of the request.

## Expected effort

Expected effort: **3-5 hours**.

Keep it practical. A concise, well-reasoned submission is better than a polished but unrealistic file dump.

## Submission

Submit a zip through the Google Form and choose the `prototype` challenge type:

https://forms.gle/coTBB9UoYGNiunyN7

Do not submit solutions as GitHub issues or pull requests.

## What to submit

Use any clear structure. Suggested contents:

```text
writeup.md
revised_cad/
cam/
insert_removal_accessory/
inspection_plan.md
order_list.csv
```

Include:

- short summary of your plan and main concerns
- important Rev A issues you found
- first validation unit build plan
- follow-on 5-10 unit build plan
- CAD or drawing changes you would make before release
- CAM/setup plan for the machined body
- threaded insert manufacturing plan
- material/tool/order list
- insert-removal accessory design
- first-article inspection plan
- assumptions or missing information

For CAM, include a Fusion 360 file, another CAM file, or screenshots/writeup detailed enough to review the setup plan. Fusion 360 is available, but another CAM package is acceptable if you explain why you used it.

For the insert-removal accessory, include:

- CAD for the accessory
- printer/material choice
- print orientation and support approach
- simple section view, screenshot, or sketch showing contact surfaces
- any hardware required
- short usage note

A physical print is not required.
