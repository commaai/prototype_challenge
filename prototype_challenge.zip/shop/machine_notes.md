# Machine Notes

## CNC mill

- Haas VF-2SS 5-axis mill.
- Renishaw probing available.
- Through-spindle coolant available.
- DWO / TCPC available.
- Standard vise and strap-clamp workholding available.
- Soft jaws can be made.
- Fusion 360 CAD/CAM available.

## Lathe

- PM-1236 manual lathe.

## General shop

- Bandsaw available.
- Basic hand tools available.
- Basic deburring tools available.
- Calipers, micrometers, indicators, surface plate, height gauge, gauge pins, and thread pitch gauges available.
