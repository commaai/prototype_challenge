# Maintenance Log Snapshot

Date: 2026-05-27

| Area | Observation |
|---|---|
| Haas VF-2SS | Coolant tank approximately 38% full. |
| Haas VF-2SS | Coolant concentration 4.1% refractometer. |
| Haas VF-2SS | Renishaw calibration record dated 2026-05-10. |
| Haas vise | Small ding on fixed jaw, left side. |
| Mill tool drawer | 1/8 in ball endmill, qty 1, visibly chipped. |
| PM-1236 lathe | Cross-slide backlash approximately 0.006 in. |
| Bambu H2D #1 | Left 0.4 mm hardened nozzle, 184 print hours. |
| Bambu H2D #2 | Right nozzle partially clogged on previous job. |
| Form 4 | Gray V5 resin tank marked 70% life remaining. |
| Form 4 | Tough 2000 resin tank marked 35% life remaining. |
